var body=document.body;
{
    //最近项目
    var recentTitle=document.getElementById("recent_title");
    var recent=document.getElementById("recent");
    var arrayCode=EasyWeb.getRecentProjects();
    var array;
    if (arrayCode != "null")	array = eval(arrayCode);
    if (arrayCode == "null" || array.length == 0){
        recentTitle.parentNode.removeChild(recentTitle);
        recent.parentNode.removeChild(recent);
    }
    else{
        for (i = 0;
        i < array.length;
        i++){
            recent.innerHTML += "<b class='link' onclick='javascript:EasyWeb.openRecentWebsite(" + i + ")'>" + array[i] + "</b><br><br>";
        }
    }
}
{
    //账户
    var loginTitle=document.getElementById("login_title");
    var login=document.getElementById("login");
    if(EasyWeb.isLogined()){
        loginTitle.parentNode.removeChild(loginTitle);
        login.parentNode.removeChild(login);
    }
}
{
    //恢复
    var recoverTitle=document.getElementById("recover_title");
    var recover=document.getElementById("recover");
    var recoverBtn=document.getElementById("recover_button");
    if(EasyWeb.hasRecover()){
        var time=EasyWeb.getRecoverTime();
        recoverBtn.innerHTML=time+"的备份";
    }
    else{
        recoverTitle.parentNode.removeChild(recoverTitle);
        recover.parentNode.removeChild(recover);
        recoverBtn.parentNode.removeChild(recoverBtn);
    }
}