var body=document.body;
if (EasyWeb.getTheme()==-1)
{
    body.style.color = "#000000";
    body.style.backgroundColor = "#FFFFFF"
}
else if (EasyWeb.getTheme()==0)
{
    body.style.color = "#000000";
    body.style.backgroundColor = "#FFFFFF"
}
else if (EasyWeb.getTheme()==1)
{
    body.style.color = "#ffffff";
    body.style.backgroundColor = "#000000"
}